# Leash Upgrade

![-redacted- ~ Vexatos 2015](oredict:oc:leashUpgrade)

拴绳升级允许无人机和机器人去牵引生物。
