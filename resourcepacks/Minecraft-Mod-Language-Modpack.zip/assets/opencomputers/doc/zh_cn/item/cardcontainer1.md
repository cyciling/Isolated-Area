# 卡包

![Can haz cards!](oredict:oc:cardContainer1)

[机器人](../block/robot.md) 的物品栏升级之一,允许热插拔卡.单个槽最大卡数等于这个升级的等级.这个容器的复杂度是一般的两倍.参见[机器人复杂度](../block/robot.md)
