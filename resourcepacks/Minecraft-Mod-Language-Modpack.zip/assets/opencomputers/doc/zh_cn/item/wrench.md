# Scrench

![Made in Swiss.](oredict:oc:wrench)

扳手 => 融合了螺丝刀和普通扳手的功能，可以拿来旋转方块