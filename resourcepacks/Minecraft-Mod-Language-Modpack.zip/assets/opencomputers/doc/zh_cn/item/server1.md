# Server

![Serves u right.](oredict:oc:server1)

服务器是高级 [电脑](../general/computer.md). 可以通过把物品拿在手上并使用来配置， 就像打开背包和箱子一样，也可以放在[机架](../block/rack.md)里面，通过站在机架的“正面”并激活它来配置. 参见[机架](../block/rack.md) entry.

T1服务器配置: 
- 1x T2 [CPU](cpu2.md)
- 2x T2 [内存](ram3.md)
- 2x T2 [硬盘](hdd2.md)
- 1x T2 [组件总线](componentBus2.md)
- 2x T2 扩展卡
- 1x [E2PROM](eeprom.md)

T2服务器配置: 
- 1x T3 [CPU](cpu3.md)
- 3x T3 [内存](ram5.md)
- 3x T3 [硬盘](hdd3.md)
- 2x T3 [组件总线](componentBus3.md)
- 2x T2扩展卡 
- 1x T3扩展卡 
- 1x [E2PROM](eeprom.md)

T3服务器配置: 
- 1x T3 [CPU](cpu3.md)
- 4x T3 [内存](ram5.md)
- 4x T3 [硬盘](hdd3.md)
- 3x T3 [组件总线](componentBus3.md)
- 2x T2扩展卡
- 2x T3扩展卡
- 1x [E2PROM](eeprom.md)

T4服务器配置: 
- 1x T3 [CPU](cpu3.md)
- 4x T3 [内存](ram5.md)
- 4x T3 [硬盘](hdd3.md)
- 3x T3 [组件总线](componentBus3.md)
- 4x T3扩展卡
- 1x [E2PROM](eeprom.md)
